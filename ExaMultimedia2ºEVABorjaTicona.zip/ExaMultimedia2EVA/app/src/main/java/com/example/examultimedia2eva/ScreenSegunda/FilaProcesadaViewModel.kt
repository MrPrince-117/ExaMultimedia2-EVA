package com.example.examultimedia2eva.ScreenSegunda

class FilaProcesadaViewModel {
}