package com.example.examultimedia2eva.Navegation


import kotlinx.serialization.Serializable
@Serializable
object AñadirScreens

@Serializable
object FilaProcesadaScreen

